package com.sticker.catalog_service.config;

import com.sticker.catalog_service.model.Material;
import com.sticker.catalog_service.repository.MaterialRepository;
import net.datafaker.Faker;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Configuration;

import java.util.List;
import java.util.Random;
import java.util.Locale;

@Configuration
public class CatalogDataLoader implements CommandLineRunner {

    private final MaterialRepository materialRepository;
    private final Faker faker = new Faker(new Locale("es"));
    private final Random random = new Random();

    private static final List<String> TIPOS_MATERIAL = List.of(
            "Vinilo Brillante", "Vinilo Mate", "Papel Couché", "Vinilo Transparente",
            "Holográfico", "Vinilo Texturado", "Kraft", "Vinilo Removible",
            "Poliéster Blanco", "Vinilo Metálico"
    );

    public CatalogDataLoader(MaterialRepository materialRepository) {
        this.materialRepository = materialRepository;
    }

    @Override
    public void run(String... args) {
        if (materialRepository.count() > 0) {
            System.out.println("Ya existen materiales en la base de datos, se omite la carga de DataFaker");
            return;
        }

        for (String tipo : TIPOS_MATERIAL) {
            Material material = new Material();
            material.setNombreMaterial(tipo);
            material.setPrecioPorCm2(redondear(faker.number().randomDouble(2, 0, 5) + 0.05));
            material.setStockActual((double) faker.number().numberBetween(50, 1000));
            material.setDescripcion(faker.lorem().sentence(10));
            materialRepository.save(material);
        }

        System.out.println(TIPOS_MATERIAL.size() + " materiales de prueba generados");
    }

    private Double redondear(double valor) {
        return Math.round(valor * 100.0) / 100.0;
    }
}
