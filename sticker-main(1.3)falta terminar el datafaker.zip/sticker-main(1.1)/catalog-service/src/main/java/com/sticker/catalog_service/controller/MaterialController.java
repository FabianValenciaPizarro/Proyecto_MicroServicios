package com.sticker.catalog_service.controller;

import com.sticker.catalog_service.dto.MaterialDTO;
import com.sticker.catalog_service.model.Material;
import com.sticker.catalog_service.service.MaterialService;
import jakarta.validation.Valid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.hateoas.CollectionModel;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.Link;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;

@RestController
@RequestMapping("/api/materiales")
public class MaterialController {

    private static final Logger log = LoggerFactory.getLogger(MaterialController.class);
    private final MaterialService materialService;

    public MaterialController(MaterialService materialService) {
        this.materialService = materialService;
    }

    private EntityModel<Material> toModel(Material material) {
        return EntityModel.of(material,
                linkTo(methodOn(MaterialController.class).buscarPorId(material.getId())).withSelfRel(),
                linkTo(methodOn(MaterialController.class).listar()).withRel("todos")
        );
    }

    @GetMapping
    public ResponseEntity<CollectionModel<EntityModel<Material>>> listar() {
        log.info("GET /api/materiales");

        List<EntityModel<Material>> materiales = materialService.listarTodos()
                .stream()
                .map(this::toModel)
                .toList();

        Link selfLink = linkTo(methodOn(MaterialController.class).listar()).withSelfRel();
        return ResponseEntity.ok(CollectionModel.of(materiales, selfLink));
    }

    @GetMapping("/{id}")
    public ResponseEntity<EntityModel<Material>> buscarPorId(@PathVariable Long id) {
        log.info("GET /api/materiales/{}", id);

        return materialService.buscarPorId(id)
                .map(material -> ResponseEntity.ok(toModel(material)))
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public ResponseEntity<EntityModel<Material>> crear(@Valid @RequestBody MaterialDTO dto) {
        log.info("POST /api/materiales");

        Material nuevo = materialService.crear(dto);
        return ResponseEntity.status(HttpStatus.CREATED).body(toModel(nuevo));
    }

    @PutMapping("/{id}")
    public ResponseEntity<EntityModel<Material>> actualizar(@PathVariable Long id, @Valid @RequestBody MaterialDTO dto) {
        log.info("PUT /api/materiales/{}", id);

        Material actualizado = materialService.actualizar(id, dto);
        return ResponseEntity.ok(toModel(actualizado));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable Long id) {
        log.info("DELETE /api/materiales/{}", id);
        materialService.eliminar(id);
        return ResponseEntity.noContent().build();
    }
}