package com.sticker.order_service.controller;

import com.sticker.order_service.dto.PedidoDTO;
import com.sticker.order_service.model.Pedido;
import com.sticker.order_service.service.PedidoService;
import jakarta.validation.Valid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.hateoas.CollectionModel;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.Link;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;

@RestController
@RequestMapping("/api/pedidos")
public class PedidoController {

    private static final Logger log = LoggerFactory.getLogger(PedidoController.class);
    private final PedidoService pedidoService;

    public PedidoController(PedidoService pedidoService) {
        this.pedidoService = pedidoService;
    }

    private EntityModel<Pedido> toModel(Pedido pedido) {
        return EntityModel.of(pedido,
                linkTo(methodOn(PedidoController.class).buscarPorId(pedido.getId())).withSelfRel(),
                linkTo(methodOn(PedidoController.class).listar()).withRel("todos"),
                linkTo(methodOn(PedidoController.class).buscarPorUsuario(pedido.getUsuarioId())).withRel("por-usuario")
        );
    }

    @GetMapping
    public ResponseEntity<CollectionModel<EntityModel<Pedido>>> listar() {
        log.info("GET /api/pedidos");

        List<EntityModel<Pedido>> pedidos = pedidoService.listarTodos()
                .stream()
                .map(this::toModel)
                .toList();

        Link selfLink = linkTo(methodOn(PedidoController.class).listar()).withSelfRel();
        return ResponseEntity.ok(CollectionModel.of(pedidos, selfLink));
    }

    @GetMapping("/{id}")
    public ResponseEntity<EntityModel<Pedido>> buscarPorId(@PathVariable Long id) {
        log.info("GET /api/pedidos/{}", id);

        return pedidoService.buscarPorId(id)
                .map(pedido -> ResponseEntity.ok(toModel(pedido)))
                .orElse(ResponseEntity.notFound().build());
    }

    @GetMapping("/usuario/{usuarioId}")
    public ResponseEntity<CollectionModel<EntityModel<Pedido>>> buscarPorUsuario(@PathVariable Long usuarioId) {
        log.info("GET /api/pedidos/usuario/{}", usuarioId);

        List<EntityModel<Pedido>> pedidos = pedidoService.buscarPorUsuario(usuarioId)
                .stream()
                .map(this::toModel)
                .toList();

        Link selfLink = linkTo(methodOn(PedidoController.class).buscarPorUsuario(usuarioId)).withSelfRel();
        Link todosLink = linkTo(methodOn(PedidoController.class).listar()).withRel("todos");
        return ResponseEntity.ok(CollectionModel.of(pedidos, selfLink, todosLink));
    }

    @PostMapping
    public ResponseEntity<EntityModel<Pedido>> crear(@Valid @RequestBody PedidoDTO dto) {
        log.info("POST /api/pedidos");

        Pedido nuevo = pedidoService.crear(dto);
        return ResponseEntity.status(HttpStatus.CREATED).body(toModel(nuevo));
    }

    @PutMapping("/{id}/estado")
    public ResponseEntity<EntityModel<Pedido>> actualizarEstado(@PathVariable Long id, @RequestParam String estado) {
        log.info("PUT /api/pedidos/{}/estado", id);

        Pedido actualizado = pedidoService.actualizarEstado(id, estado);
        return ResponseEntity.ok(toModel(actualizado));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable Long id) {
        log.info("DELETE /api/pedidos/{}", id);
        pedidoService.eliminar(id);
        return ResponseEntity.noContent().build();
    }
}