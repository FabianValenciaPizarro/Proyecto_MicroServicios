package com.sticker.order_service.config;

import com.sticker.order_service.model.Pedido;
import com.sticker.order_service.repository.PedidoRepository;
import net.datafaker.Faker;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Configuration;

import java.util.List;
import java.util.Locale;
import java.util.Random;

@Configuration
public class OrderDataLoader implements CommandLineRunner {

    private final PedidoRepository pedidoRepository;
    private final Faker faker = new Faker(new Locale("es"));
    private final Random random = new Random();

    private static final int CANTIDAD_PEDIDOS = 10;

    private static final long USUARIO_ID_MIN = 1;
    private static final long USUARIO_ID_MAX = 10;
    private static final long MATERIAL_ID_MIN = 1;
    private static final long MATERIAL_ID_MAX = 10;

    private static final List<String> ESTADOS_PAGO = List.of("PENDIENTE", "PAGADO", "CANCELADO");

    public OrderDataLoader(PedidoRepository pedidoRepository) {
        this.pedidoRepository = pedidoRepository;
    }

    @Override
    public void run(String... args) {
        if (pedidoRepository.count() > 0) {
            System.out.println("Ya existen pedidos en la base de datos, se omite la carga de DataFaker");
            return;
        }

        for (int i = 0; i < CANTIDAD_PEDIDOS; i++) {
            Long usuarioId = randomEntre(USUARIO_ID_MIN, USUARIO_ID_MAX);
            Long materialId = randomEntre(MATERIAL_ID_MIN, MATERIAL_ID_MAX);

            Double anchoCm = redondear(faker.number().randomDouble(1, 5, 50));
            Double altoCm = redondear(faker.number().randomDouble(1, 5, 50));
            Integer cantidad = faker.number().numberBetween(1, 100);

            Double precioEstimado = redondear(faker.number().randomDouble(2, 0, 5) + 0.1);
            Double montoTotal = redondear(anchoCm * altoCm * precioEstimado * cantidad);

            Pedido pedido = new Pedido();
            pedido.setUsuarioId(usuarioId);
            pedido.setMaterialId(materialId);
            pedido.setAnchoCm(anchoCm);
            pedido.setAltoCm(altoCm);
            pedido.setCantidad(cantidad);
            pedido.setMontoTotal(montoTotal);
            pedido.setEstadoPago(ESTADOS_PAGO.get(random.nextInt(ESTADOS_PAGO.size())));

            pedidoRepository.save(pedido);
        }

        System.out.println(CANTIDAD_PEDIDOS + " pedidos de prueba generados con DataFaker");
    }

    private Long randomEntre(long min, long max) {
        return min + (long) (random.nextDouble() * (max - min + 1));
    }

    private Double redondear(double valor) {
        return Math.round(valor * 100.0) / 100.0;
    }
}
