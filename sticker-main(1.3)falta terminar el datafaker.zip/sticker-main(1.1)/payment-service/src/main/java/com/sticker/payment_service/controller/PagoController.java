package com.sticker.payment_service.controller;

import com.sticker.payment_service.dto.PagoDTO;
import com.sticker.payment_service.model.Pago;
import com.sticker.payment_service.service.PagoService;
import jakarta.validation.Valid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.hateoas.CollectionModel;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.Link;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;

@RestController
@RequestMapping("/api/pagos")
public class PagoController {

    private static final Logger log = LoggerFactory.getLogger(PagoController.class);
    private final PagoService pagoService;

    public PagoController(PagoService pagoService) {
        this.pagoService = pagoService;
    }
    
    private EntityModel<Pago> toModel(Pago pago) {
        return EntityModel.of(pago,
                linkTo(methodOn(PagoController.class).buscarPorId(pago.getId())).withSelfRel(),
                linkTo(methodOn(PagoController.class).listar()).withRel("todos"),
                linkTo(methodOn(PagoController.class).buscarPorPedido(pago.getPedidoId())).withRel("por-pedido")
        );
    }

    @GetMapping
    public ResponseEntity<CollectionModel<EntityModel<Pago>>> listar() {
        log.info("GET /api/pagos");

        List<EntityModel<Pago>> pagos = pagoService.listarTodos()
                .stream()
                .map(this::toModel)
                .toList();

        Link selfLink = linkTo(methodOn(PagoController.class).listar()).withSelfRel();
        return ResponseEntity.ok(CollectionModel.of(pagos, selfLink));
    }

    @GetMapping("/{id}")
    public ResponseEntity<EntityModel<Pago>> buscarPorId(@PathVariable Long id) {
        log.info("GET /api/pagos/{}", id);

        return pagoService.buscarPorId(id)
                .map(pago -> ResponseEntity.ok(toModel(pago)))
                .orElse(ResponseEntity.notFound().build());
    }

    @GetMapping("/pedido/{pedidoId}")
    public ResponseEntity<CollectionModel<EntityModel<Pago>>> buscarPorPedido(@PathVariable Long pedidoId) {
        log.info("GET /api/pagos/pedido/{}", pedidoId);

        List<EntityModel<Pago>> pagos = pagoService.buscarPorPedido(pedidoId)
                .stream()
                .map(this::toModel)
                .toList();

        Link selfLink = linkTo(methodOn(PagoController.class).buscarPorPedido(pedidoId)).withSelfRel();
        Link todosLink = linkTo(methodOn(PagoController.class).listar()).withRel("todos");
        return ResponseEntity.ok(CollectionModel.of(pagos, selfLink, todosLink));
    }

    @PostMapping
    public ResponseEntity<EntityModel<Pago>> procesar(@Valid @RequestBody PagoDTO dto) {
        log.info("POST /api/pagos");

        Pago nuevo = pagoService.procesar(dto);
        return ResponseEntity.status(HttpStatus.CREATED).body(toModel(nuevo));
    }

    @PutMapping("/{id}/estado")
    public ResponseEntity<EntityModel<Pago>> actualizarEstado(@PathVariable Long id, @RequestParam String estado) {
        log.info("PUT /api/pagos/{}/estado", id);

        Pago actualizado = pagoService.actualizarEstado(id, estado);
        return ResponseEntity.ok(toModel(actualizado));
    }
}