package com.sticker.user_service.controller;

import com.sticker.user_service.dto.UsuarioDTO;
import com.sticker.user_service.model.Usuario;
import com.sticker.user_service.service.UsuarioService;
import jakarta.validation.Valid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.hateoas.CollectionModel;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.Link;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;

@RestController
@RequestMapping("/api/usuarios")
public class UsuarioController {

    private static final Logger log = LoggerFactory.getLogger(UsuarioController.class);
    private final UsuarioService usuarioService;

    public UsuarioController(UsuarioService usuarioService) {
        this.usuarioService = usuarioService;
    }
    
    private EntityModel<Usuario> toModel(Usuario usuario) {
        return EntityModel.of(usuario,
                linkTo(methodOn(UsuarioController.class).buscarPorId(usuario.getId())).withSelfRel(),
                linkTo(methodOn(UsuarioController.class).listar()).withRel("todos")
        );
    }

    @GetMapping
    public ResponseEntity<CollectionModel<EntityModel<Usuario>>> listar() {
        log.info("GET /api/usuarios");

        List<EntityModel<Usuario>> usuarios = usuarioService.listarTodos()
                .stream()
                .map(this::toModel)
                .toList();

        Link selfLink = linkTo(methodOn(UsuarioController.class).listar()).withSelfRel();
        return ResponseEntity.ok(CollectionModel.of(usuarios, selfLink));
    }

    @GetMapping("/{id}")
    public ResponseEntity<EntityModel<Usuario>> buscarPorId(@PathVariable Long id) {
        log.info("GET /api/usuarios/{}", id);

        return usuarioService.buscarPorId(id)
                .map(usuario -> ResponseEntity.ok(toModel(usuario)))
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public ResponseEntity<EntityModel<Usuario>> crear(@Valid @RequestBody UsuarioDTO dto) {
        log.info("POST /api/usuarios");

        Usuario nuevo = usuarioService.crear(dto);
        return ResponseEntity.status(HttpStatus.CREATED).body(toModel(nuevo));
    }

    @PutMapping("/{id}")
    public ResponseEntity<EntityModel<Usuario>> actualizar(@PathVariable Long id, @Valid @RequestBody UsuarioDTO dto) {
        log.info("PUT /api/usuarios/{}", id);

        Usuario actualizado = usuarioService.actualizar(id, dto);
        return ResponseEntity.ok(toModel(actualizado));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable Long id) {
        log.info("DELETE /api/usuarios/{}", id);
        usuarioService.eliminar(id);
        return ResponseEntity.noContent().build();
    }
}