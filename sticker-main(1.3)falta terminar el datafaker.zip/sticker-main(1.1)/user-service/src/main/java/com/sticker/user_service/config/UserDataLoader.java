package com.sticker.user_service.config;

import com.sticker.user_service.model.Usuario;
import com.sticker.user_service.repository.UsuarioRepository;
import net.datafaker.Faker;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import java.util.Locale;

@Configuration
public class UserDataLoader implements CommandLineRunner {

    private final UsuarioRepository usuarioRepository;
    private final BCryptPasswordEncoder passwordEncoder;
    private final Faker faker = new Faker(new Locale("es"));

    private static final int CANTIDAD_USUARIOS = 10;

    public UserDataLoader(UsuarioRepository usuarioRepository,
                          BCryptPasswordEncoder passwordEncoder) {
        this.usuarioRepository = usuarioRepository;
        this.passwordEncoder = passwordEncoder;
    }

    @Override
    public void run(String... args) {
        if (usuarioRepository.count() > 0) {
            System.out.println("Ya existen usuarios en la base de datos, se omite la carga de DataFaker");
            return;
        }

        int creados = 0;
        int intentos = 0;

        while (creados < CANTIDAD_USUARIOS && intentos < CANTIDAD_USUARIOS * 3) {
            intentos++;

            String nombreBase = faker.name().firstName() + "." + faker.name().lastName();
            String username = nombreBase.toLowerCase()
                    .replaceAll("[^a-z0-9.]", "");
            String email = username + "@" + faker.internet().domainName();

            if (usuarioRepository.existsByUsername(username) || usuarioRepository.existsByEmail(email)) {
                continue;
            }

            Usuario usuario = new Usuario();
            usuario.setUsername(username);
            usuario.setPassword(passwordEncoder.encode("password123"));
            usuario.setEmail(email);

            usuario.setRole(creados == 0 ? Usuario.Role.ADMIN : Usuario.Role.CLIENTE);

            usuarioRepository.save(usuario);
            creados++;
        }

        System.out.println(creados + " usuarios de prueba generados con DataFaker (password: password123)");
    }
}
