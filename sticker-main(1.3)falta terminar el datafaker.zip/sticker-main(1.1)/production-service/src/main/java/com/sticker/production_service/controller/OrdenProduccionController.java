package com.sticker.production_service.controller;

import com.sticker.production_service.dto.OrdenProduccionDTO;
import com.sticker.production_service.model.OrdenProduccion;
import com.sticker.production_service.service.OrdenProduccionService;
import jakarta.validation.Valid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.hateoas.CollectionModel;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.Link;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;

@RestController
@RequestMapping("/api/produccion")
public class OrdenProduccionController {

    private static final Logger log = LoggerFactory.getLogger(OrdenProduccionController.class);
    private final OrdenProduccionService ordenService;

    public OrdenProduccionController(OrdenProduccionService ordenService) {
        this.ordenService = ordenService;
    }

    // ── Helper: convierte una OrdenProduccion en EntityModel con sus links ──
    private EntityModel<OrdenProduccion> toModel(OrdenProduccion orden) {
        return EntityModel.of(orden,
                linkTo(methodOn(OrdenProduccionController.class).buscarPorId(orden.getId())).withSelfRel(),
                linkTo(methodOn(OrdenProduccionController.class).listar()).withRel("todas"),
                linkTo(methodOn(OrdenProduccionController.class).buscarPorPedido(orden.getPedidoId())).withRel("por-pedido"),
                linkTo(methodOn(OrdenProduccionController.class).buscarPorEstado(orden.getEstadoProduccion())).withRel("por-estado")
        );
    }

    @GetMapping
    public ResponseEntity<CollectionModel<EntityModel<OrdenProduccion>>> listar() {
        log.info("GET /api/produccion");

        List<EntityModel<OrdenProduccion>> ordenes = ordenService.listarTodos()
                .stream()
                .map(this::toModel)
                .toList();

        Link selfLink = linkTo(methodOn(OrdenProduccionController.class).listar()).withSelfRel();
        return ResponseEntity.ok(CollectionModel.of(ordenes, selfLink));
    }

    @GetMapping("/{id}")
    public ResponseEntity<EntityModel<OrdenProduccion>> buscarPorId(@PathVariable Long id) {
        log.info("GET /api/produccion/{}", id);

        return ordenService.buscarPorId(id)
                .map(orden -> ResponseEntity.ok(toModel(orden)))
                .orElse(ResponseEntity.notFound().build());
    }

    @GetMapping("/pedido/{pedidoId}")
    public ResponseEntity<CollectionModel<EntityModel<OrdenProduccion>>> buscarPorPedido(@PathVariable Long pedidoId) {
        log.info("GET /api/produccion/pedido/{}", pedidoId);

        List<EntityModel<OrdenProduccion>> ordenes = ordenService.buscarPorPedido(pedidoId)
                .stream()
                .map(this::toModel)
                .toList();

        Link selfLink = linkTo(methodOn(OrdenProduccionController.class).buscarPorPedido(pedidoId)).withSelfRel();
        Link todasLink = linkTo(methodOn(OrdenProduccionController.class).listar()).withRel("todas");
        return ResponseEntity.ok(CollectionModel.of(ordenes, selfLink, todasLink));
    }

    @GetMapping("/estado/{estado}")
    public ResponseEntity<CollectionModel<EntityModel<OrdenProduccion>>> buscarPorEstado(@PathVariable String estado) {
        log.info("GET /api/produccion/estado/{}", estado);

        List<EntityModel<OrdenProduccion>> ordenes = ordenService.buscarPorEstado(estado)
                .stream()
                .map(this::toModel)
                .toList();

        Link selfLink = linkTo(methodOn(OrdenProduccionController.class).buscarPorEstado(estado)).withSelfRel();
        Link todasLink = linkTo(methodOn(OrdenProduccionController.class).listar()).withRel("todas");
        return ResponseEntity.ok(CollectionModel.of(ordenes, selfLink, todasLink));
    }

    @PostMapping
    public ResponseEntity<EntityModel<OrdenProduccion>> crear(@Valid @RequestBody OrdenProduccionDTO dto) {
        log.info("POST /api/produccion");

        OrdenProduccion nueva = ordenService.crear(dto);
        EntityModel<OrdenProduccion> model = toModel(nueva);
        return ResponseEntity.status(HttpStatus.CREATED).body(model);
    }

    @PutMapping("/{id}/estado")
    public ResponseEntity<EntityModel<OrdenProduccion>> actualizarEstado(@PathVariable Long id, @RequestParam String estado) {
        log.info("PUT /api/produccion/{}/estado", id);

        OrdenProduccion actualizada = ordenService.actualizarEstado(id, estado);
        return ResponseEntity.ok(toModel(actualizada));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable Long id) {
        log.info("DELETE /api/produccion/{}", id);
        ordenService.eliminar(id);
        return ResponseEntity.noContent().build();
    }
}