package com.sticker.production_service.config;

import com.sticker.production_service.model.OrdenProduccion;
import com.sticker.production_service.repository.OrdenProduccionRepository;
import net.datafaker.Faker;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Configuration;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Locale;
import java.util.Random;

@Configuration
public class ProductionDataLoader implements CommandLineRunner {

    private final OrdenProduccionRepository ordenRepository;
    private final Faker faker = new Faker(new Locale("es"));
    private final Random random = new Random();

    private static final int CANTIDAD_ORDENES = 10;

    private static final long PEDIDO_ID_MIN = 1;
    private static final long PEDIDO_ID_MAX = 10;

    private static final List<String> ESTADOS = List.of("PENDIENTE", "EN_PROCESO", "TERMINADO", "CANCELADO");

    public ProductionDataLoader(OrdenProduccionRepository ordenRepository) {
        this.ordenRepository = ordenRepository;
    }

    @Override
    public void run(String... args) {
        if (ordenRepository.count() > 0) {
            System.out.println("Ya existen órdenes de producción en la base de datos, se omite la carga de DataFaker");
            return;
        }

        for (int i = 0; i < CANTIDAD_ORDENES; i++) {
            Long pedidoId = randomEntre(PEDIDO_ID_MIN, PEDIDO_ID_MAX);
            String estado = ESTADOS.get(random.nextInt(ESTADOS.size()));

            OrdenProduccion orden = new OrdenProduccion();
            orden.setPedidoId(pedidoId);
            orden.setDisenoUrl("https://cdn.stickerapp.test/disenos/" + faker.internet().slug() + ".png");
            orden.setEstadoProduccion(estado);

            LocalDateTime fechaInicio = LocalDateTime.now().minusDays(faker.number().numberBetween(1, 15));
            orden.setFechaInicio(fechaInicio);

            if (estado.equals("TERMINADO")) {
                orden.setFechaTermino(fechaInicio.plusDays(faker.number().numberBetween(1, 5)));
            }

            ordenRepository.save(orden);
        }

        System.out.println(CANTIDAD_ORDENES + " órdenes de producción de prueba generadas con DataFaker");
    }

    private Long randomEntre(long min, long max) {
        return min + (long) (random.nextDouble() * (max - min + 1));
    }
}