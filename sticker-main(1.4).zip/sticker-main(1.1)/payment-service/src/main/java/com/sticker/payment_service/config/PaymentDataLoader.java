package com.sticker.payment_service.config;

import com.sticker.payment_service.model.Pago;
import com.sticker.payment_service.repository.PagoRepository;
import net.datafaker.Faker;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Configuration;

import java.util.List;
import java.util.Locale;
import java.util.Random;
import java.util.UUID;

@Configuration
public class PaymentDataLoader implements CommandLineRunner {

    private final PagoRepository pagoRepository;
    private final Faker faker = new Faker(new Locale("es"));
    private final Random random = new Random();

    private static final int CANTIDAD_PAGOS = 10;

    private static final long PEDIDO_ID_MIN = 1;
    private static final long PEDIDO_ID_MAX = 10;

    private static final List<String> METODOS_PAGO = List.of(
            "Tarjeta de Crédito", "Tarjeta de Débito", "Transferencia Bancaria",
            "PayPal", "Mercado Pago", "Efectivo"
    );

    private static final List<String> ESTADOS_PAGO = List.of("PENDIENTE", "PAGADO", "RECHAZADO", "REEMBOLSADO");

    public PaymentDataLoader(PagoRepository pagoRepository) {
        this.pagoRepository = pagoRepository;
    }

    @Override
    public void run(String... args) {
        if (pagoRepository.count() > 0) {
            System.out.println("Ya existen pagos en la base de datos, se omite la carga de DataFaker");
            return;
        }

        for (int i = 0; i < CANTIDAD_PAGOS; i++) {
            Long pedidoId = randomEntre(PEDIDO_ID_MIN, PEDIDO_ID_MAX);
            String estado = ESTADOS_PAGO.get(random.nextInt(ESTADOS_PAGO.size()));

            Pago pago = new Pago();
            pago.setPedidoId(pedidoId);
            pago.setMetodoPago(METODOS_PAGO.get(random.nextInt(METODOS_PAGO.size())));
            pago.setMonto(redondear(faker.number().randomDouble(2, 5, 500)));
            pago.setEstado(estado);
            pago.setTransaccionId(UUID.randomUUID().toString());

            pagoRepository.save(pago);
        }

        System.out.println(CANTIDAD_PAGOS + " pagos de prueba generados");
    }

    private Long randomEntre(long min, long max) {
        return min + (long) (random.nextDouble() * (max - min + 1));
    }

    private Double redondear(double valor) {
        return Math.round(valor * 100.0) / 100.0;
    }
}